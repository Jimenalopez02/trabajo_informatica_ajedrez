﻿#include "Tablero.h"
#include "Peon.h"
#include "Caballo.h"
#include "Torre.h"
#include "Canciller.h"
#include "Alfil.h"
#include "Arzobispo.h"
#include "Reina.h"
#include "Rey.h"
#include "ETSIDI.h"
#include <iostream>

Tablero::Tablero(Jugador& j1, Jugador& j2)
    : jugador1(j1), jugador2(j2) {
    casillas.resize(FILAS_TABLERO, std::vector<Pieza*>(COLUMNAS_TABLERO, nullptr));
    CasillasaCoordenadas();
    inicializaTablero();
}

Tablero::~Tablero() {
    for (auto& fila : casillas)
        for (auto& p : fila)
            delete p;
}

void Tablero::CasillasaCoordenadas() {
    int k = 0;
    for (int fila = 0; fila < FILAS_TABLERO; fila++) {
        for (int col = 0; col < COLUMNAS_TABLERO; col++) {
            coordenadaSobreTablero[k].x = MARGEN_X + col * TAM_CASILLA + TAM_CASILLA / 2.0f;
            coordenadaSobreTablero[k].y = MARGEN_Y + fila * TAM_CASILLA + TAM_CASILLA / 2.0f;
            k++;
        }
    }
}

void Tablero::inicializaTablero() {
    std::vector<ConfigPieza> piezasTablero = {
        {TipoPieza::Torre,0},{TipoPieza::Caballo,1},{TipoPieza::Canciller,2},
        {TipoPieza::Alfil,3},{TipoPieza::Reina,4},{TipoPieza::Rey,5},
        {TipoPieza::Arzobispo,7},{TipoPieza::Alfil,6},{TipoPieza::Caballo,8},
        {TipoPieza::Torre,9}
    };

    for (int col = 0; col < COLUMNAS_TABLERO; ++col) {
        Pieza* peonBlanco = new Peon(ColorBlancas, 1, col, *this);
        casillas[1][col] = peonBlanco;
        jugador1.agregarPieza(peonBlanco);

        Pieza* peonNegro = new Peon(ColorNegras, 6, col, *this);
        casillas[6][col] = peonNegro;
        jugador2.agregarPieza(peonNegro);
    }

    inicializarPiezasJugador(*this, jugador1, ColorBlancas, 0, piezasTablero);
    inicializarPiezasJugador(*this, jugador2, ColorNegras, 7, piezasTablero);
}
Pieza* Tablero::crearPieza(TipoPieza tipo, int color, int fila, int columna, Tablero& tablero) {
    switch (tipo) {
    case TipoPieza::Torre: return new Torre(color, fila, columna, tablero);
    case TipoPieza::Caballo: return new Caballo(color, fila, columna, tablero);
    case TipoPieza::Canciller: return new Canciller(color, fila, columna, tablero);
    case TipoPieza::Alfil: return new Alfil(color, fila, columna, tablero);
    case TipoPieza::Arzobispo: return new Arzobispo(color, fila, columna, tablero);
    case TipoPieza::Reina: return new Reina(color, fila, columna, tablero);
    case TipoPieza::Rey: return new Rey(color, fila, columna, tablero);
    default: return nullptr;
    }
}
void Tablero::inicializarPiezasJugador(Tablero& tablero, Jugador& jugador, int color, int fila, const std::vector<ConfigPieza>& configuracion) {
    for (const auto& conf : configuracion) {
        Pieza* p = crearPieza(conf.tipo, color, fila, conf.columna, tablero);
        tablero.casillas[fila][conf.columna] = p;
        jugador.agregarPieza(p);
    }
}
void Tablero::dibujar() const {
    glEnable(GL_TEXTURE_2D);
    glDisable(GL_LIGHTING);

    GLuint textura = ETSIDI::getTexture("imagenes/tablero_etsidi.png").id;
    glBindTexture(GL_TEXTURE_2D, textura);

    glBegin(GL_QUADS);
    glColor3f(1, 1, 1);
    glTexCoord2d(0, 1); glVertex2f(MARGEN_X, MARGEN_Y);
    glTexCoord2d(1, 1); glVertex2f(MARGEN_X + TAM_CASILLA * COLUMNAS_TABLERO, MARGEN_Y);
    glTexCoord2d(1, 0); glVertex2f(MARGEN_X + TAM_CASILLA * COLUMNAS_TABLERO, MARGEN_Y + TAM_CASILLA * FILAS_TABLERO);
    glTexCoord2d(0, 0); glVertex2f(MARGEN_X, MARGEN_Y + TAM_CASILLA * FILAS_TABLERO);
    glEnd();

    glDisable(GL_TEXTURE_2D);
    glEnable(GL_LIGHTING);

    for (int fila = 0; fila < FILAS_TABLERO; fila++) {
        for (int col = 0; col < COLUMNAS_TABLERO; col++) {
            if (casillas[fila][col]) {
                int index = fila * COLUMNAS_TABLERO + col;
                float x = coordenadaSobreTablero[index].x;
                float y = coordenadaSobreTablero[index].y;
                casillas[fila][col]->dibujaPieza(x, y, TAM_CASILLA);
            }
        }
    }
}

Pieza* Tablero::getPieza(int fila, int columna)const  {
    if (fila < 0 || fila >= FILAS_TABLERO || columna < 0 || columna >= COLUMNAS_TABLERO)
        return nullptr;
    return casillas[fila][columna];
}

void Tablero::moverPieza(const Casilla& origen, const Casilla& destino) {
    Pieza* pieza = casillas[origen.fila][origen.columna];
    if (!pieza) return;

    std::cout << "Moviendo pieza de (" << origen.fila << "," << origen.columna << ") a ("
        << destino.fila << "," << destino.columna << ")\n";

    // 1. Evaluar si es una captura al paso
    if (pieza->getTipo() == TipoPieza::Peon &&
        origen.columna != destino.columna &&
        casillas[destino.fila][destino.columna] == nullptr &&
        hayCapturaAlPaso &&
        destino == posibleCapturaAlPaso) {

        std::cout << "Captura al paso detectada\n";
        Pieza* capturada = casillas[peonVulnerableAlPaso.fila][peonVulnerableAlPaso.columna];
        if (capturada) {
            eliminarPiezaDeJugador(capturada);
            delete capturada;
            casillas[peonVulnerableAlPaso.fila][peonVulnerableAlPaso.columna] = nullptr;
            std::cout << "Peón capturado al paso en ("
                << peonVulnerableAlPaso.fila << "," << peonVulnerableAlPaso.columna << ")\n";
        }
    }

    // 2. Captura normal
    Pieza* destinoPieza = casillas[destino.fila][destino.columna];
    if (destinoPieza != nullptr) {
        eliminarPiezaDeJugador(destinoPieza);
        delete destinoPieza;
        std::cout << "Pieza capturada en destino\n";
    }

    // Verificar si es promoción
    if (pieza->getTipo() == TipoPieza::Peon &&
        ((pieza->getColor() == ColorBlancas && destino.fila == 7) ||
            (pieza->getColor() == ColorNegras && destino.fila == 0))) {

        if (promocionarPeon(pieza, destino)) {
            casillas[origen.fila][origen.columna] = nullptr; // limpiar la casilla origen
            return; // Termina aquí porque ya hicimos la promoción y actualización del tablero
        }
    }

    // Si no es promoción, mover normal
    pieza->setFila(destino.fila);
    pieza->setColumna(destino.columna);
    //pieza->setSeHaMovido(true);
    casillas[destino.fila][destino.columna] = pieza;
    casillas[origen.fila][origen.columna] = nullptr;

    // 4. Evaluar si se habilita la captura al paso (para el próximo turno del rival)
    if (pieza->getTipo() == TipoPieza::Peon && std::abs(destino.fila - origen.fila) == 2) {
        hayCapturaAlPaso = true;
        posibleCapturaAlPaso = { (origen.fila + destino.fila) / 2, destino.columna };
        peonVulnerableAlPaso = destino;
        std::cout << "Peón vulnerable al paso en (" << destino.fila << "," << destino.columna << ")\n";
    }
    else {
        hayCapturaAlPaso = false;
    }

}

bool Tablero::casillaOcupada(int fila, int columna) const {
    if (fila < 0 || fila >= FILAS_TABLERO || columna < 0 || columna >= COLUMNAS_TABLERO)
        return false;
    return casillas[fila][columna] != nullptr;
}

bool Tablero::hayPiezaOponente(int fila, int columna, bool turnoBlancas) const {
    if (fila < 0 || fila >= FILAS_TABLERO || columna < 0 || columna >= COLUMNAS_TABLERO)
        return false;

    Pieza* p = casillas[fila][columna];
    if (!p) return false;

    return p->getColor() != (turnoBlancas ? ColorBlancas : ColorNegras);
}

std::vector<Casilla> Tablero::obtenerMovimientosPermitidos(int fila, int columna, bool turnoBlancas) const {
    if (fila < 0 || fila >= FILAS_TABLERO || columna < 0 || columna >= COLUMNAS_TABLERO)
        return {};

    Pieza* p = casillas[fila][columna];
    if (!p) return {};

    if ((turnoBlancas && p->getColor() != ColorBlancas) ||
        (!turnoBlancas && p->getColor() != ColorNegras))
        return {};

    return p->getMovimientosPermitidos(p->getFila(), p->getColumna(), turnoBlancas);
}
bool Tablero::estaEnJaque(const Jugador& jugador, const Jugador& oponente) {
    // 1. Buscar al rey del jugador
    Pieza* rey = nullptr;
    for (Pieza* p : jugador.getPiezas()) {
        if (p && p->getTipo() == TipoPieza::Rey) {
            rey = p;
            break;
        }
    }

    if (!rey) return false;  // No hay rey

    int filaRey = rey->getFila();
    int colRey = rey->getColumna();

    // 2. Ver si alguna pieza enemiga puede capturar al rey
    for (Pieza* piezaEnemiga : oponente.getPiezas()) {
        if (!piezaEnemiga) continue;

        std::vector<Casilla> movimientos = piezaEnemiga->getMovimientosPermitidos(
            piezaEnemiga->getFila(), piezaEnemiga->getColumna(),
            oponente.getColor() == ColorBlancas
        );

        for (const Casilla& mov : movimientos) {
            if (mov.fila == filaRey && mov.columna == colRey) {
                return true; // El rey está amenazado
            }
        }
    }

    return false; // Rey no está en jaque
}
bool Tablero::esMovimientoLegal(const Casilla& origen, const Casilla& destino, Jugador& jugador, Jugador& oponente) {
    Pieza* piezaOrigen = casillas[origen.fila][origen.columna];
    Pieza* piezaDestino = casillas[destino.fila][destino.columna];

    if (!piezaOrigen) return false;

    // Simula el movimiento
    casillas[destino.fila][destino.columna] = piezaOrigen;
    casillas[origen.fila][origen.columna] = nullptr;

    int filaOriginal = piezaOrigen->getFila();
    int colOriginal = piezaOrigen->getColumna();

    piezaOrigen->setFila(destino.fila);
    piezaOrigen->setColumna(destino.columna);

    // Eliminar temporalmente pieza capturada, sin importar si es aliada o enemiga
    std::vector<Pieza*>* vectorPiezas = nullptr;
    bool piezaCapturada = false;

    if (piezaDestino) {
        if (piezaDestino->getColor() == jugador.getColor()) {
            vectorPiezas = &jugador.getPiezas();
        }
        else {
            vectorPiezas = &oponente.getPiezas();
        }

        auto it = std::find(vectorPiezas->begin(), vectorPiezas->end(), piezaDestino);
        if (it != vectorPiezas->end()) {
            vectorPiezas->erase(it);
            piezaCapturada = true;
        }
    }

    // Evaluar si el rey está en jaque
    bool enJaque = estaEnJaque(jugador, oponente);

    // Revertir el movimiento
    casillas[origen.fila][origen.columna] = piezaOrigen;
    casillas[destino.fila][destino.columna] = piezaDestino;
    piezaOrigen->setFila(filaOriginal);
    piezaOrigen->setColumna(colOriginal);

    // Restaurar pieza capturada si existía
    if (piezaCapturada && vectorPiezas) {
        vectorPiezas->push_back(piezaDestino);
    }

    return !enJaque;
}
void Tablero::eliminarPiezaDeJugador(Pieza* pieza) {
    Jugador* dueño = pieza->getColor() == ColorBlancas ? &jugador1 : &jugador2;

    auto& piezas = dueño->getPiezas();
    piezas.erase(std::remove(piezas.begin(), piezas.end(), pieza), piezas.end());
}

bool Tablero::estaEnJaqueMate(Jugador& jugador, Jugador& oponente) {
    // 1. Comprobar si está en jaque
    if (!estaEnJaque(jugador, oponente)) {
        return false; // No está en jaque, por lo tanto no es jaque mate
    }

    // 2. Ver si alguna pieza puede hacer un movimiento legal que saque al rey del jaque
    for (Pieza* pieza : jugador.getPiezas()) {
        std::vector<Casilla> movimientos = pieza->getMovimientosPermitidos(pieza->getFila(), pieza->getColumna(), jugador.getColor());

        for (const Casilla& destino : movimientos) {
            Casilla origen = { pieza->getFila(), pieza->getColumna() };

            if (esMovimientoLegal(origen, destino, jugador, oponente)) {
                return false; // Existe al menos un movimiento legal que evita el jaque mate
            }
        }
    }

    // 3. No hay ningún movimiento legal que evite el jaque => Jaque mate
    return true;
}
TipoPieza Tablero::pedirPromocion() {
    std::cout << "Elige pieza para promocionar:\n";
    std::cout << "1 - Dama\n";
    std::cout << "2 - Torre\n";
    std::cout << "3 - Alfil\n";
    std::cout << "4 - Caballo\n";
    std::cout << "5 - Arzobispo\n";
    std::cout << "6 - Canciller\n";

    int opcion = 0;
    while (true) {
        std::cout << "Ingresa número (1-6): ";
        std::cin >> opcion;

        if (opcion >= 1 && opcion <= 6) {
            switch (opcion) {
            case 1: return TipoPieza::Reina;
            case 2: return TipoPieza::Torre;
            case 3: return TipoPieza::Alfil;
            case 4: return TipoPieza::Caballo;
            case 5: return TipoPieza::Arzobispo;
            case 6: return TipoPieza::Canciller;
            }
        }
        std::cout << "Opción inválida. Intenta otra vez.\n";
    }
}
bool Tablero::promocionarPeon(Pieza* peon, const Casilla& destino) {
    TipoPieza tipoPromocion = pedirPromocion();
    int color = peon->getColor();

    eliminarPiezaDeJugador(peon);
    delete peon;
    casillas[destino.fila][destino.columna] = nullptr;

    Pieza* piezaPromocionada = crearPieza(tipoPromocion, color, destino.fila, destino.columna, *this);

    casillas[destino.fila][destino.columna] = piezaPromocionada;

    Jugador* jugador = (color == ColorBlancas) ? &jugador1 : &jugador2;
    jugador->getPiezas().push_back(piezaPromocionada);
    return true;
}
/*bool Tablero::puedeEnrocar(const Casilla& casillaRey, const Casilla& casillaTorre, int color) const {
    Pieza* rey = getPieza(casillaRey.fila, casillaRey.columna);
    Pieza* torre = getPieza(casillaTorre.fila, casillaTorre.columna);

    // 1. Comprobar que rey y torre existan y sean del tipo correcto
    if (!rey || rey->getTipo() != TipoPieza::Rey) return false;
    if (!torre || torre->getTipo() != TipoPieza::Torre) return false;

    // 2. Comprobar que ambos sean del color correspondiente
    if (rey->getColor() != color || torre->getColor() != color) return false;

    // 3. Verificar que rey y torre no se hayan movido
    if (rey->getSeHaMovido() || torre->getSeHaMovido()) return false;

    // 4. Obtener referencias a jugador y oponente por color
    const Jugador& jugador = (color == ColorBlancas) ? jugador1 : jugador2;
    const Jugador& oponente = (color == ColorBlancas) ? jugador2 : jugador1;

    // 5. Verificar que el rey no esté en jaque
    if (estaEnJaque(jugador, oponente)) return false;

    // 6. Verificar que las casillas entre rey y torre estén vacías
    int fila = casillaRey.fila;
    int colInicio, colFin;
    if (casillaRey.columna < casillaTorre.columna) {
        colInicio = casillaRey.columna + 1;
        colFin = casillaTorre.columna - 1;
    }
    else {
        colInicio = casillaTorre.columna + 1;
        colFin = casillaRey.columna - 1;
    }
    for (int c = colInicio; c <= colFin; ++c) {
        if (casillaOcupada(fila, c)) return false;
    }

    // 7. Verificar que las casillas por las que pasa el rey no estén amenazadas
    int direccion = (casillaTorre.columna > casillaRey.columna) ? 1 : -1;

    for (int i = 0; i <= 2; ++i) {
        Casilla casillaPaso = { fila, casillaRey.columna + i * direccion };
        if (estaAmenazada(casillaPaso, oponente)) return false;
    }

    return true;
}

bool Tablero::estaAmenazada(const Casilla& casilla, const Jugador& enemigo) const {
    // Por cada pieza enemiga
    for (auto* pieza : enemigo.getPiezas()) {
        auto movimientos = pieza->getMovimientosPermitidos(pieza->getFila(), pieza->getColumna(), enemigo.getColor());
        for (const auto& mov : movimientos) {
            if (mov.fila == casilla.fila && mov.columna == casilla.columna) {
                return true;
            }
        }
    }
    return false;
}
void Tablero::hacerEnroque(const Casilla& casillaRey, const Casilla& casillaTorre) {
    Pieza* rey = getPieza(casillaRey.fila, casillaRey.columna);
    Pieza* torre = getPieza(casillaTorre.fila, casillaTorre.columna);

    if (!rey || !torre) return;

    int fila = casillaRey.fila;
    int direccion = (casillaTorre.columna - casillaRey.columna) > 0 ? 1 : -1;

    // El rey salta 3 casillas en tu variante (una más de lo normal)
    Casilla nuevaPosRey = { fila, casillaRey.columna + 3 * direccion };

    // La torre se mueve a la casilla justo al lado del rey, del lado opuesto
    Casilla nuevaPosTorre = { fila, nuevaPosRey.columna - direccion };

    // Mover rey
    casillas[casillaRey.fila][casillaRey.columna] = nullptr;
    casillas[nuevaPosRey.fila][nuevaPosRey.columna] = rey;
    rey->setFila(nuevaPosRey.fila);
    rey->setColumna(nuevaPosRey.columna);
    rey->setSeHaMovido(true);

    // Mover torre
    casillas[casillaTorre.fila][casillaTorre.columna] = nullptr;
    casillas[nuevaPosTorre.fila][nuevaPosTorre.columna] = torre;
    torre->setFila(nuevaPosTorre.fila);
    torre->setColumna(nuevaPosTorre.columna);
    torre->setSeHaMovido(true);
    std::cout << "Enroque realizado correctamente\n";
}*/