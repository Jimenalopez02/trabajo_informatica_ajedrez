#pragma once
class Coordenada
{
public:
	double x, y;
};

