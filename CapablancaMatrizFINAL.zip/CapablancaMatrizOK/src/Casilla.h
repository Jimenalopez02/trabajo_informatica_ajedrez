#pragma once
class Casilla
{
public:
	int fila;
	int columna;
	Casilla() : fila(0), columna(0) {};
	Casilla(int f, int c) : fila(f), columna(c) {};
	bool operator==(const Casilla& c) const {
		return fila == c.fila && columna == c.columna;
	}
};

